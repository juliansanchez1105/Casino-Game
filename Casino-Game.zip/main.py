#hello
import time as t, sys, random as r, pickle, os

bank = pickle.load(open("bankFile", "rb"))

play = True

print("PLAY IN MAX CONSOLE SIZE FOR BEST EXPERIENCE!!!")
t.sleep(5)
os.system("clear")

print('''
 /__  ___/ //    / / //   / /       //   ) )  // | |     //   ) )  / /    /|    / / //   ) )       //   ) )  // | |     /|    //| |     //   / / 
   / /    //___ / / //____         //        //__| |    ((        / /    //|   / / //   / /       //        //__| |    //|   // | |    //____    
  / /    / ___   / / ____         //        / ___  |      \ \    / /    // |  / / //   / /       //  ____  / ___  |   // |  //  | |   / ____     
 / /    //    / / //             //        //    | |        ) ) / /    //  | / / //   / /       //    / / //    | |  //  | //   | |  //          
/ /    //    / / //____/ /      ((____/ / //     | | ((___ / /_/ /___ //   |/ / ((___/ /       ((____/ / //     | | //   |//    | | //____/ /    
                                                  _________________________________
                                                |  __    __    ___  _____    __   |  
                                                | / _\  / /   /___\/__   \  / _\  | 
                                                | \ \  / /   //  //  / /\ \ \ \   |  
                                                | _\ \/ /___/ \_//  / /  \/ _\ \  | 
                                                | \__/\____/\___/   \/      \__/  | __
                                                |===_______===_______===_______===|(  )
                                                ||*|  ___  |*|\_     |*|  ___  |*|| ||
                                                ||*| |_  | |*|| \ _  |*| |_  | |*|| ||
                                                ||*|  / /  |*| \_(_) |*|  / /  |*|| ||
                                                ||*| /_/   |*| (_)   |*| /_/   |*|| ||
                                                ||*|_______|*|_______|*|_______|*||_//
                                                |===_______===_______===_______===|_/
                                                |===___________________________===|
                                                |  /___________________________\  |
                                                |   |                         |   |
                                                _|   \_______________________/    |_
                                              (_____________________________________)''')
t.sleep(6)
def slow_print(text):
    for character in text + '\n':
        sys.stdout.write(character)
        sys.stdout.flush()
        t.sleep(.025)


def diceroll_1():
    global money
    slow_print("You will now roll your dice against an opponent")
    slow_print(
        "You have " + str(money) +
        " dollars. How much are you willing to bet?\nIf you win, you will get twice as much as you bet.\nEnter a whole number:"
    )
    wholenum = False
    while wholenum == False:
        try:
            bet = round(int(input()))
            wholenum = True
            if bet > money or bet < 0:
                slow_print("You can't bet that much money, try again:")
                wholenum = False
        except:
            slow_print("Please input a whole number:")
    opponentRoll = r.randint(1, 6)
    yourRoll = r.randint(1, 6)
    slow_print("Your opponent has rolled a " + str(opponentRoll))
    slow_print("You have rolled a " + str(yourRoll))
    if opponentRoll > yourRoll:
        slow_print("You lost... both the game and the money")
        money -= bet
    elif opponentRoll < yourRoll:
        slow_print("You WON! Your money was doubled")
        money += bet
    elif opponentRoll == yourRoll:
        slow_print("It's a tie. You don't lose your money.")
    print("You currently have " + str(money) + " dollars.")
    updateBank()


def diceroll_2():
    global money
    slow_print(
        "Welcome to the diceroll table! You will try and guess what you will roll"
    )
    slow_print(
        "You have " + str(money) +
        " dollars.\nHow much are you willing to bet?\nIf you win, you will get thrice as much as you bet.\nEnter a whole number:"
    )
    wholenum = False
    while wholenum == False:
        try:
            bet = round(int(input()))
            wholenum = True
            if bet > money or bet < 0:
                slow_print("You can't bet that much money, try again:")
                wholenum = False
        except:
            slow_print("Please input a whole number:")
    slow_print(
        "Choose a number in between 1 and 6 inclusive.\nIf the number you choose is the same as the dice roll,\nyou triple your bet amount. "
    )
    usernum = int(input())
    randnum = r.randint(1, 6)
    if usernum == randnum:
        print("Congratulations! Your number was the same as the dice roll!")
        money = money + (bet * 2)
    else:
        print("You chose " + str(usernum) + " but the dice rolled a " +
              str(randnum) + ". Better luck next time!")
        money -= bet
    print("You currently have " + str(money) + " dollars.")
    updateBank()


def wheelspin():
    global money
    slow_print(
        "You will now guess whether the wheel will land on an even or odd number"
    )
    slow_print(
        "You have " + str(money) +
        " dollars. How much are you willing to bet?\nIf you win, you will get twice as much as you bet.\nEnter a whole number:"
    )
    wholenum = False
    while wholenum == False:
        try:
            bet = round(int(input()))
            wholenum = True
            if bet > money or bet < 0:
                slow_print("You can't bet that much money, try again:")
                wholenum = False
        except:
            slow_print("Please input a whole number:")
    slow_print(
        "Do you think you will land on an 'even' number or an 'odd' number?")
    guess = input().lower().strip()
    spin = r.randint(1, 40)
    slow_print("You spun a " + str(spin))
    if (spin % 2 == 0) and ('even' == guess):
        slow_print("YOU WON!!! Your bet was doubled")
        money += bet
    if (spin % 2 == 0) and ('odd' in guess):
        slow_print("You lost...")
        money -= bet
    if (spin % 2 == 1) and ('even' in guess):
        slow_print("You lost...")
        money -= bet
    if (spin % 2 == 1) and ('odd' in guess):
        slow_print("YOU WON!!! Your bet was doubled")
        money += bet
    slow_print("You currently have " + str(money) + " dollars")
    updateBank()


def slotmachine():
    global money
    symbols = ['!', '#', '%']
    slow_print("Welcome to the slotmachine game!")
    slow_print(
        "To play the game you will put in a bet amount and then 3 symbols will appear.\nThe symbols are %, #, and !. To win money, you must get the same symbol in all 3 slots.\nIf this happens you will recieve ten times your bet. Good luck!!"
    )
    slow_print("You have " + str(money) +
               " dollars. How much are you willing to bet?")
    wholenum = False
    while wholenum == False:
        try:
            bet = round(int(input()))
            wholenum = True
            if bet > money or bet < 0:
                slow_print("You can't bet that much money, try again:")
                wholenum = False
        except:
            slow_print("Please input a whole number:")
    money -= bet
    sq1 = r.choice(symbols)
    sq2 = r.choice(symbols)
    sq3 = r.choice(symbols)
    print()
    print("(", sq1, "|", sq2, "|", sq3, ")\n")
    if sq1 == sq2 and sq2 == sq3:
        money = bet * 10 + money
        slow_print("Nice job you now have " + str(money) + " dollars.")
    elif (sq1 != sq2 or sq2 != sq3 or sq1 != sq3):
        slow_print("Unlucky, I'm sure you'll get it next time.")
        slow_print("You now have " + str(money) + " dollars.")
    updateBank()


def gameStart():
    t.sleep(1)
    os.system("clear")
    slow_print(
        "Welcome to the Casino.\nTry and turn your 1000 dollars into 500,000!\nWould you like to log into your account\nor create a new one? login/account"
    )
    gameLoginAnswer = input("").strip().lower()
    if gameLoginAnswer == "login":
        bankLogin()
    elif gameLoginAnswer == "account":
        addAccount()
    else:
        slow_print("Try Again!")
        gameStart()


def addAccount():
    global bank
    t.sleep(1)
    os.system("clear")
    slow_print("Are you here to add an account? y/n")
    addAccountAnswer = input("").strip().lower()
    if addAccountAnswer == "n":
        gameStart()
    elif addAccountAnswer == "y":
        slow_print(
            "What would you like your password to be? \nCapitalization and trailing spaces will not be recorded."
        )
        password = input("Enter Here: ").strip().lower()
        if password in bank:
            slow_print("Sorry, that password is already taken, try again.")
            addAccount()
        else:
            bank[password] = 1000
            pickle.dump(bank, open("bankFile", "wb"))
            slow_print(
                "You now have $1000 in your account. \nHere, have a look!")
            bankLogin()
    else:
        slow_print("try again")
        addAccount()


def bankLogin():
    global bank
    global money
    global login
    t.sleep(1)
    os.system("clear")
    bank = pickle.load(open("bankFile", "rb"))
    slow_print("Enter your password to log in:")
    login = input("").strip().lower()
    if login in bank:
        money = bank[login]
        slow_print("Login Successful \nYou have: $" + str(bank[login]) +
                   " in your account!")
    else:
        slow_print(
            "Sorry, it looks like that is not a valid password. \nDo you want to start a new account? y/n"
        )
        accountAddAnswer2 = input("").strip().lower()
        if accountAddAnswer2 == "y":
            addAccount()
        elif accountAddAnswer2 == "n":
            slow_print("Okay")
            bankLogin()
        else:
            slow_print("Sorry, that is not a valid answer. \nTry again")
            bankLogin()


def updateBank():
    global bank
    global money
    global login
    bank[login] = money
    pickle.dump(bank, open("bankFile", "wb"))


gameStart()

while play == True and money < 500000:
    slow_print(
        "Where would you like to head over: To the Dice Roll, Wheel Spin,\nor Slot Machine"
    )
    game_choice = input().lower().strip()
    if ("dice" in game_choice or "roll" in game_choice):
        slow_print("You have headed over to the dice roll")
        slow_print(
            "Would you like to try and roll higher than your opponent (type '1') or\nattempt to guess what you will roll (type '2')."
        )
        dice_game_choice = input().strip()
        if dice_game_choice == '1':
            diceroll_1()
        if dice_game_choice == '2':
            diceroll_2()
    elif ("wheel" in game_choice or "spin" in game_choice):
        slow_print("You have headed over to the wheel spin")
        wheelspin()
    elif ("slot" in game_choice or "machine" in game_choice):
        slow_print("You have headed over to the slot machine")
        slotmachine()
    if money <= 0:
        slow_print("You don't have any more money!")
        slow_print("You went bankrupt and lost the game...")
        play = False
    if money >= 500_000:
        slow_print("You have become rich!")
        slow_print("You WON!")
        play = False

if money >= 500000:
    slow_print(
        "Do you want to reset your progress or continue indefinitely? reset/continue"
    )
    resetBool = True
    while resetBool == True:
        resetAnswer = input("").strip().lower()
        if resetAnswer == "reset":
            slow_print("Resetting Game...")
            money = 1000
            updateBank()
            play = False
            resetBool = False
        elif resetAnswer == "continue":
            slow_print("Your Game is continued...")
            play = True
            resetBool = False
        else:
            slow_print("That isn't a valid choice")
    while play == True:
        slow_print(
            "Where would you like to head over: To the Dice Roll, Wheel Spin,\nor Slot Machine"
        )
        game_choice = input().lower().strip()
        if ("dice" in game_choice or "roll" in game_choice):
            slow_print("You have headed over to the dice roll")
            slow_print(
                "Would you like to try and roll higher than your opponent (type '1') or\nattempt to guess what you will roll (type '2')."
            )
            dice_game_choice = input().strip()
        if dice_game_choice == '1':
            diceroll_1()
        if dice_game_choice == '2':
            diceroll_2()
        elif ("wheel" in game_choice or "spin" in game_choice):
            slow_print("You have headed over to the wheel spin")
            wheelspin()
        elif ("slot" in game_choice or "machine" in game_choice):
            slow_print("You have headed over to the slot machine")
            slotmachine()
elif money <= 0:
    slow_print("Your progress has reset.")
    money = 1000
    updateBank()